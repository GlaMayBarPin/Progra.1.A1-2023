﻿
namespace LACTEOS
{
    partial class Proveedores
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label nombre_del_proveedoresLabel;
            System.Windows.Forms.Label correo_electrónicoLabel;
            System.Windows.Forms.Label dirección_Label;
            System.Windows.Forms.Label teléfonoLabel;
            System.Windows.Forms.Label id_productosLabel;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Proveedores));
            this.datos__de_los_proveedoresBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.datos__de_los_proveedoresBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.proveedoresDataSet = new LACTEOS.proveedoresDataSet();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.nombre_del_proveedoresTextBox = new System.Windows.Forms.TextBox();
            this.correo_electrónicoTextBox = new System.Windows.Forms.TextBox();
            this.dirección_TextBox = new System.Windows.Forms.TextBox();
            this.teléfonoTextBox = new System.Windows.Forms.TextBox();
            this.id_productosTextBox = new System.Windows.Forms.TextBox();
            this.datos__de_los_proveedoresDataGridView = new System.Windows.Forms.DataGridView();
            this.idDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nombredelproveedoresDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.correoElectrónicoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.direcciónDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.teléfonoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.idproductosDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.datos__de_los_proveedoresTableAdapter = new LACTEOS.proveedoresDataSetTableAdapters.Datos__de_los_proveedoresTableAdapter();
            this.tableAdapterManager = new LACTEOS.proveedoresDataSetTableAdapters.TableAdapterManager();
            this.button1 = new System.Windows.Forms.Button();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.datos__de_los_proveedoresBindingNavigatorSaveItem = new System.Windows.Forms.ToolStripButton();
            nombre_del_proveedoresLabel = new System.Windows.Forms.Label();
            correo_electrónicoLabel = new System.Windows.Forms.Label();
            dirección_Label = new System.Windows.Forms.Label();
            teléfonoLabel = new System.Windows.Forms.Label();
            id_productosLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.datos__de_los_proveedoresBindingNavigator)).BeginInit();
            this.datos__de_los_proveedoresBindingNavigator.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.datos__de_los_proveedoresBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.proveedoresDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.datos__de_los_proveedoresDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // nombre_del_proveedoresLabel
            // 
            nombre_del_proveedoresLabel.AutoSize = true;
            nombre_del_proveedoresLabel.Location = new System.Drawing.Point(9, 97);
            nombre_del_proveedoresLabel.Name = "nombre_del_proveedoresLabel";
            nombre_del_proveedoresLabel.Size = new System.Drawing.Size(126, 13);
            nombre_del_proveedoresLabel.TabIndex = 3;
            nombre_del_proveedoresLabel.Text = "Nombre del proveedores:";
            // 
            // correo_electrónicoLabel
            // 
            correo_electrónicoLabel.AutoSize = true;
            correo_electrónicoLabel.Location = new System.Drawing.Point(12, 131);
            correo_electrónicoLabel.Name = "correo_electrónicoLabel";
            correo_electrónicoLabel.Size = new System.Drawing.Size(96, 13);
            correo_electrónicoLabel.TabIndex = 5;
            correo_electrónicoLabel.Text = "Correo electrónico:";
            // 
            // dirección_Label
            // 
            dirección_Label.AutoSize = true;
            dirección_Label.Location = new System.Drawing.Point(24, 164);
            dirección_Label.Name = "dirección_Label";
            dirección_Label.Size = new System.Drawing.Size(58, 13);
            dirección_Label.TabIndex = 7;
            dirección_Label.Text = "Dirección :";
            // 
            // teléfonoLabel
            // 
            teléfonoLabel.AutoSize = true;
            teléfonoLabel.Location = new System.Drawing.Point(30, 212);
            teléfonoLabel.Name = "teléfonoLabel";
            teléfonoLabel.Size = new System.Drawing.Size(52, 13);
            teléfonoLabel.TabIndex = 9;
            teléfonoLabel.Text = "Teléfono:";
            // 
            // id_productosLabel
            // 
            id_productosLabel.AutoSize = true;
            id_productosLabel.Location = new System.Drawing.Point(24, 253);
            id_productosLabel.Name = "id_productosLabel";
            id_productosLabel.Size = new System.Drawing.Size(68, 13);
            id_productosLabel.TabIndex = 11;
            id_productosLabel.Text = "id productos:";
            // 
            // datos__de_los_proveedoresBindingNavigator
            // 
            this.datos__de_los_proveedoresBindingNavigator.AddNewItem = this.bindingNavigatorAddNewItem;
            this.datos__de_los_proveedoresBindingNavigator.BindingSource = this.datos__de_los_proveedoresBindingSource;
            this.datos__de_los_proveedoresBindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.datos__de_los_proveedoresBindingNavigator.DeleteItem = this.bindingNavigatorDeleteItem;
            this.datos__de_los_proveedoresBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem,
            this.datos__de_los_proveedoresBindingNavigatorSaveItem});
            this.datos__de_los_proveedoresBindingNavigator.Location = new System.Drawing.Point(0, 0);
            this.datos__de_los_proveedoresBindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.datos__de_los_proveedoresBindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.datos__de_los_proveedoresBindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.datos__de_los_proveedoresBindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.datos__de_los_proveedoresBindingNavigator.Name = "datos__de_los_proveedoresBindingNavigator";
            this.datos__de_los_proveedoresBindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.datos__de_los_proveedoresBindingNavigator.Size = new System.Drawing.Size(674, 25);
            this.datos__de_los_proveedoresBindingNavigator.TabIndex = 0;
            this.datos__de_los_proveedoresBindingNavigator.Text = "bindingNavigator1";
            // 
            // datos__de_los_proveedoresBindingSource
            // 
            this.datos__de_los_proveedoresBindingSource.DataMember = "Datos_ de_los_proveedores";
            this.datos__de_los_proveedoresBindingSource.DataSource = this.proveedoresDataSet;
            // 
            // proveedoresDataSet
            // 
            this.proveedoresDataSet.DataSetName = "proveedoresDataSet";
            this.proveedoresDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(37, 22);
            this.bindingNavigatorCountItem.Text = "de {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Número total de elementos";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Posición";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Posición actual";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator1";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator2";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // nombre_del_proveedoresTextBox
            // 
            this.nombre_del_proveedoresTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.datos__de_los_proveedoresBindingSource, "Nombre_del_proveedores", true));
            this.nombre_del_proveedoresTextBox.Location = new System.Drawing.Point(141, 97);
            this.nombre_del_proveedoresTextBox.Name = "nombre_del_proveedoresTextBox";
            this.nombre_del_proveedoresTextBox.Size = new System.Drawing.Size(214, 20);
            this.nombre_del_proveedoresTextBox.TabIndex = 4;
            // 
            // correo_electrónicoTextBox
            // 
            this.correo_electrónicoTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.datos__de_los_proveedoresBindingSource, "Correo electrónico", true));
            this.correo_electrónicoTextBox.Location = new System.Drawing.Point(114, 128);
            this.correo_electrónicoTextBox.Name = "correo_electrónicoTextBox";
            this.correo_electrónicoTextBox.Size = new System.Drawing.Size(209, 20);
            this.correo_electrónicoTextBox.TabIndex = 6;
            // 
            // dirección_TextBox
            // 
            this.dirección_TextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.datos__de_los_proveedoresBindingSource, "Dirección ", true));
            this.dirección_TextBox.Location = new System.Drawing.Point(114, 161);
            this.dirección_TextBox.Multiline = true;
            this.dirección_TextBox.Name = "dirección_TextBox";
            this.dirección_TextBox.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.dirección_TextBox.Size = new System.Drawing.Size(241, 36);
            this.dirección_TextBox.TabIndex = 8;
            // 
            // teléfonoTextBox
            // 
            this.teléfonoTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.datos__de_los_proveedoresBindingSource, "Teléfono", true));
            this.teléfonoTextBox.Location = new System.Drawing.Point(114, 209);
            this.teléfonoTextBox.Name = "teléfonoTextBox";
            this.teléfonoTextBox.Size = new System.Drawing.Size(209, 20);
            this.teléfonoTextBox.TabIndex = 10;
            // 
            // id_productosTextBox
            // 
            this.id_productosTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.datos__de_los_proveedoresBindingSource, "id_productos", true));
            this.id_productosTextBox.Location = new System.Drawing.Point(114, 250);
            this.id_productosTextBox.Name = "id_productosTextBox";
            this.id_productosTextBox.Size = new System.Drawing.Size(209, 20);
            this.id_productosTextBox.TabIndex = 12;
            // 
            // datos__de_los_proveedoresDataGridView
            // 
            this.datos__de_los_proveedoresDataGridView.AllowUserToAddRows = false;
            this.datos__de_los_proveedoresDataGridView.AllowUserToDeleteRows = false;
            this.datos__de_los_proveedoresDataGridView.AutoGenerateColumns = false;
            this.datos__de_los_proveedoresDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.datos__de_los_proveedoresDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idDataGridViewTextBoxColumn,
            this.nombredelproveedoresDataGridViewTextBoxColumn,
            this.correoElectrónicoDataGridViewTextBoxColumn,
            this.direcciónDataGridViewTextBoxColumn,
            this.teléfonoDataGridViewTextBoxColumn,
            this.idproductosDataGridViewTextBoxColumn});
            this.datos__de_los_proveedoresDataGridView.DataSource = this.datos__de_los_proveedoresBindingSource;
            this.datos__de_los_proveedoresDataGridView.Location = new System.Drawing.Point(12, 308);
            this.datos__de_los_proveedoresDataGridView.Name = "datos__de_los_proveedoresDataGridView";
            this.datos__de_los_proveedoresDataGridView.ReadOnly = true;
            this.datos__de_los_proveedoresDataGridView.Size = new System.Drawing.Size(643, 171);
            this.datos__de_los_proveedoresDataGridView.TabIndex = 12;
            // 
            // idDataGridViewTextBoxColumn
            // 
            this.idDataGridViewTextBoxColumn.DataPropertyName = "Id";
            this.idDataGridViewTextBoxColumn.HeaderText = "Id";
            this.idDataGridViewTextBoxColumn.Name = "idDataGridViewTextBoxColumn";
            this.idDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // nombredelproveedoresDataGridViewTextBoxColumn
            // 
            this.nombredelproveedoresDataGridViewTextBoxColumn.DataPropertyName = "Nombre_del_proveedores";
            this.nombredelproveedoresDataGridViewTextBoxColumn.HeaderText = "Nombre_del_proveedores";
            this.nombredelproveedoresDataGridViewTextBoxColumn.Name = "nombredelproveedoresDataGridViewTextBoxColumn";
            this.nombredelproveedoresDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // correoElectrónicoDataGridViewTextBoxColumn
            // 
            this.correoElectrónicoDataGridViewTextBoxColumn.DataPropertyName = "Correo electrónico";
            this.correoElectrónicoDataGridViewTextBoxColumn.HeaderText = "Correo electrónico";
            this.correoElectrónicoDataGridViewTextBoxColumn.Name = "correoElectrónicoDataGridViewTextBoxColumn";
            this.correoElectrónicoDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // direcciónDataGridViewTextBoxColumn
            // 
            this.direcciónDataGridViewTextBoxColumn.DataPropertyName = "Dirección ";
            this.direcciónDataGridViewTextBoxColumn.HeaderText = "Dirección ";
            this.direcciónDataGridViewTextBoxColumn.Name = "direcciónDataGridViewTextBoxColumn";
            this.direcciónDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // teléfonoDataGridViewTextBoxColumn
            // 
            this.teléfonoDataGridViewTextBoxColumn.DataPropertyName = "Teléfono";
            this.teléfonoDataGridViewTextBoxColumn.HeaderText = "Teléfono";
            this.teléfonoDataGridViewTextBoxColumn.Name = "teléfonoDataGridViewTextBoxColumn";
            this.teléfonoDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // idproductosDataGridViewTextBoxColumn
            // 
            this.idproductosDataGridViewTextBoxColumn.DataPropertyName = "id_productos";
            this.idproductosDataGridViewTextBoxColumn.HeaderText = "id_productos";
            this.idproductosDataGridViewTextBoxColumn.Name = "idproductosDataGridViewTextBoxColumn";
            this.idproductosDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "Id";
            this.dataGridViewTextBoxColumn1.HeaderText = "Id";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "Nombre_del_proveedores";
            this.dataGridViewTextBoxColumn2.HeaderText = "Nombre_del_proveedores";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "Correo electrónico";
            this.dataGridViewTextBoxColumn3.HeaderText = "Correo electrónico";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "Dirección ";
            this.dataGridViewTextBoxColumn4.HeaderText = "Dirección ";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "Teléfono";
            this.dataGridViewTextBoxColumn5.HeaderText = "Teléfono";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.DataPropertyName = "id_productos";
            this.dataGridViewTextBoxColumn6.HeaderText = "id_productos";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            // 
            // datos__de_los_proveedoresTableAdapter
            // 
            this.datos__de_los_proveedoresTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.Datos__de_los_proveedoresTableAdapter = this.datos__de_los_proveedoresTableAdapter;
            this.tableAdapterManager.UpdateOrder = LACTEOS.proveedoresDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(206, 510);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(217, 30);
            this.button1.TabIndex = 14;
            this.button1.Text = "producto de la tabla 2 ";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = global::LACTEOS.Properties.Resources.quesos_y_mas_logo_7EA29788E9_seeklogo_com;
            this.pictureBox4.Location = new System.Drawing.Point(408, 56);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(236, 210);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 13;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(236, 27);
            this.pictureBox3.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(67, 60);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 8;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(123, 27);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(67, 60);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 6;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(15, 27);
            this.pictureBox2.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(67, 60);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 6;
            this.pictureBox2.TabStop = false;
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorAddNewItem.Text = "Agregar nuevo";
            // 
            // bindingNavigatorDeleteItem
            // 
            this.bindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
            this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
            this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorDeleteItem.Text = "Eliminar";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem.Text = "Mover primero";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem.Text = "Mover anterior";
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveNextItem.Text = "Mover siguiente";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveLastItem.Text = "Mover último";
            // 
            // datos__de_los_proveedoresBindingNavigatorSaveItem
            // 
            this.datos__de_los_proveedoresBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.datos__de_los_proveedoresBindingNavigatorSaveItem.Image = ((System.Drawing.Image)(resources.GetObject("datos__de_los_proveedoresBindingNavigatorSaveItem.Image")));
            this.datos__de_los_proveedoresBindingNavigatorSaveItem.Name = "datos__de_los_proveedoresBindingNavigatorSaveItem";
            this.datos__de_los_proveedoresBindingNavigatorSaveItem.Size = new System.Drawing.Size(23, 22);
            this.datos__de_los_proveedoresBindingNavigatorSaveItem.Text = "Guardar datos";
            this.datos__de_los_proveedoresBindingNavigatorSaveItem.Click += new System.EventHandler(this.datos__de_los_proveedoresBindingNavigatorSaveItem_Click_2);
            // 
            // Proveedores
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(674, 562);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.datos__de_los_proveedoresDataGridView);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(nombre_del_proveedoresLabel);
            this.Controls.Add(this.nombre_del_proveedoresTextBox);
            this.Controls.Add(correo_electrónicoLabel);
            this.Controls.Add(this.correo_electrónicoTextBox);
            this.Controls.Add(dirección_Label);
            this.Controls.Add(this.dirección_TextBox);
            this.Controls.Add(teléfonoLabel);
            this.Controls.Add(this.teléfonoTextBox);
            this.Controls.Add(id_productosLabel);
            this.Controls.Add(this.id_productosTextBox);
            this.Controls.Add(this.datos__de_los_proveedoresBindingNavigator);
            this.Name = "Proveedores";
            this.Text = "Proveedores";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.datos__de_los_proveedoresBindingNavigator)).EndInit();
            this.datos__de_los_proveedoresBindingNavigator.ResumeLayout(false);
            this.datos__de_los_proveedoresBindingNavigator.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.datos__de_los_proveedoresBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.proveedoresDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.datos__de_los_proveedoresDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private proveedoresDataSet proveedoresDataSet;
        private System.Windows.Forms.BindingSource datos__de_los_proveedoresBindingSource;
        private proveedoresDataSetTableAdapters.Datos__de_los_proveedoresTableAdapter datos__de_los_proveedoresTableAdapter;
        private proveedoresDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.BindingNavigator datos__de_los_proveedoresBindingNavigator;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton datos__de_los_proveedoresBindingNavigatorSaveItem;
        private System.Windows.Forms.TextBox nombre_del_proveedoresTextBox;
        private System.Windows.Forms.TextBox correo_electrónicoTextBox;
        private System.Windows.Forms.TextBox dirección_TextBox;
        private System.Windows.Forms.TextBox teléfonoTextBox;
        private System.Windows.Forms.TextBox id_productosTextBox;
        private System.Windows.Forms.DataGridView datos__de_los_proveedoresDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn idDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nombredelproveedoresDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn correoElectrónicoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn direcciónDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn teléfonoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn idproductosDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.Button button1;
    }
}

